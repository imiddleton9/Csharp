
docker swarm init
