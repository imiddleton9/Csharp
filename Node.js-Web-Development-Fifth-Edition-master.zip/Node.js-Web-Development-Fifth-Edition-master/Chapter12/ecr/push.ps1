docker push %AWS_USER%.dkr.ecr.%AWS_REGION%.amazonaws.com/svc-notes:latest
docker push %AWS_USER%.dkr.ecr.%AWS_REGION%.amazonaws.com/svc-userauth:latest
