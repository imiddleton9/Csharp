import { default as simple } from './simple.js';

console.log(simple.next());
console.log(simple.next());
console.log(simple.hello());
