console.log(`dirname: ${__dirname}`);
console.log(`filename: ${__filename}`);