const A = "value A";
const B = "value B";
exports.values = function() {
   return { A: A, B: B };
}
