import feature from 'hybrid-module-1/feature';

feature.hello();